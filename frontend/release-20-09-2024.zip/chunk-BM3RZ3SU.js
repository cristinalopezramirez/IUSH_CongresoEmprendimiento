import{h as a}from"./chunk-J4ZR5Y2S.js";export default a();
